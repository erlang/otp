
Naming convension of files
==========================

* incorrect schemas  ( XXXX.e.xsd )

	schemas that should be rejected by conforming processors
	have ".e.xsd" in the name.

* correct schemas ( XXXX.xsd )

	other files with .xsd extensions are correct schemas, thus
	they should be accepted by conforming processors.

* valid documents ( XXXX.vXXXX.xml )

	correct schemas may have documents. A valid document has
	".v" in its name, and its prefix is the same as its schema.
	
	For example, "abc.def.v-xyz.xml" is a valid document for
	"abc.def.xsd".

* invalid documents ( XXXX.nXXXX.xml )

	Similary, an invalid document has ".n" in its name.

* other documents

	files with other extensions (like .xsdmod) should be ignored.
	They are usually refered from schema files.

